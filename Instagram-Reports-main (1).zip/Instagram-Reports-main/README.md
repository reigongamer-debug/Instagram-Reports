# ABOUT TOOL :

Instagram-Reports is a tool made to ban any scam or bad person.

# Installation :

```
sudo apt-get update -y
```

```
sudo apt-get upgrade -y
```
```
apt install wget -y
```
```
apt install python -y
```
```
pip install requests
```
```
pip install pyfiglet
```
```
wget https://raw.githubusercontent.com/DamnYatin/Instagram-Reports/main/reports.py
```
```
python3 reports.py
```

# 100% Legit

# Note

<li>Do not copy this tool.

## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
